﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace $safeprojectname$.Helper
{
    public class LoginHelper
    {
        EventDBEntities db = new EventDBEntities();
        internal bool LoginUser(string eMail, string password, HttpContext httpContext)
        {
            User u = db.User.Where(x => x.Email == eMail && x.Password == password).FirstOrDefault();
            if (u != null)
            {
                httpContext.Session["UserId"] = u.Id;
                httpContext.Session["FullName"] = u.FullName;
                
                return true;
            }
            else
            {
                return false;
            }

    }
    }
}