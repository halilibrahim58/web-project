﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace $safeprojectname$.Controllers
{
    public class LoginController : Controller
    {
        EventDBEntities db = new EventDBEntities();
        // GET: Login
        public ActionResult Index()
        {
            if ((Request.Cookies["EMail"] != null && Request.Cookies["Password"] != null) || Session["UserId"] != null)
            {
                return RedirectToAction("Index", "Home");
            }

            return View();
        }
        [HttpPost]
        public ActionResult Index(string EMail, string Password, string rememberMe)
        {
            if (new Helper.LoginHelper().LoginUser(EMail, Password, System.Web.HttpContext.Current))
            {
                return RedirectToAction("Index", "Home");
            }
            else
            {
                //  ViewBag.ErrorMessage = "Mail Adresi ve şifre kombinasyonu hatalı!";
                return RedirectToAction("Error", "Error");
            }
        }

        public ActionResult Logout()
        {
            Session["UserId"] = null;
            Session["FullName"] = null;
            Response.Cookies["EMail"].Expires = DateTime.Now.AddSeconds(-10);
            Response.Cookies["Password"].Expires = DateTime.Now.AddSeconds(-10);
            return RedirectToAction("Index");
        }




        public ActionResult SignUp()
        {
            return View();
        }


        [HttpPost]
        public ActionResult SignUp(User user)
        {

            if (SignUpValidation(user))
            {
                User newUser = new User();
                newUser.FullName = user.FullName;
                newUser.Email = user.Email;
                newUser.Phone = user.Phone;
                newUser.Address = user.Address;
                newUser.Password = user.Password;

                db.User.Add(newUser);
                db.SaveChanges();
            }

            return RedirectToAction("Index");

        }

        public bool SignUpValidation(User user)
        {
            User userControl = db.User.Where(x => x.Email == user.Email).FirstOrDefault();

            if (user.FullName != null &&
                user.Password != null &&
                user.Address != null &&
                user.Phone != null &&
                (user.Email != null && userControl == null))
            {
                return true;
            }
                
            else
                return false;
        }
        
    }
}