﻿using $safeprojectname$.Helper;
using $safeprojectname$.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace $safeprojectname$.Controllers
{

    public class EventController : Controller
    {

        EventDBEntities db = new EventDBEntities();
        // GET: $safeprojectname$
        public ActionResult Index()
        {
            List<$safeprojectname$> eventList = db.$safeprojectname$.ToList();
            return View(eventList);
        }


        public ActionResult EventAdd()
        {
            List<Category> catList = db.Category.ToList();
            return View(catList);
        }

        [HttpPost]
        public ActionResult EventAdd($safeprojectname$ addedEvent)
        {
            $safeprojectname$ newEvent = new $safeprojectname$();
            newEvent.Name = addedEvent.Name;
            newEvent.Place = addedEvent.Place;
            newEvent.DateOfEvent = addedEvent.DateOfEvent;
            newEvent.CategoryId = addedEvent.CategoryId;
            newEvent.ImageUrl = addedEvent.ImageUrl;
            newEvent.WebsiteLink = addedEvent.WebsiteLink;

            db.$safeprojectname$.Add(newEvent);
            db.SaveChanges();

            return RedirectToAction("Index");
        }


        public ActionResult EventDelete(int Id)
        {
            $safeprojectname$ deletedEvent = db.$safeprojectname$.Where(x => x.Id == Id).FirstOrDefault();
            db.$safeprojectname$.Remove(deletedEvent);
            db.SaveChanges();

            return RedirectToAction("Index", "Home");
        }


        public ActionResult EventList(int Id)
        {
            List<$safeprojectname$> eventList = db.$safeprojectname$.Where(x => x.CategoryId == Id).ToList();
            return View(eventList);
        }

        public ActionResult OpenedEvent(int Id)
        {
            

            OpenedEventModel openedPageModel = new OpenedEventModel();
            if (Session["UserId"] != null)
            {
                int userId = (int)Session["UserId"];
                
                openedPageModel.user = db.User.Where(x => x.Id == userId).FirstOrDefault();

                Wish wishControl = db.Wish.Where(x => x.UserId == userId && x.EventId == Id).FirstOrDefault();

                if (wishControl == null)
                    openedPageModel.isGoneToEvent = false;

                if (wishControl != null && wishControl.IsGone == true)
                    openedPageModel.isGoneToEvent = true;

                if (wishControl != null && wishControl.IsGone == false)
                    openedPageModel.isGoneToEvent = false;
            }

            openedPageModel.openedEvent = db.$safeprojectname$.Where(x => x.Id == Id).FirstOrDefault();

            return View(openedPageModel);
        }




        public ActionResult WishList()
        {
            List<Wish> wishList = new List<Wish>();
            List<$safeprojectname$> eventList = new List<$safeprojectname$>();
            int _userId = (int)Session["UserId"];
            if (Session["UserId"] != null)
            {
                wishList = db.Wish.Where(x => x.UserId == _userId).ToList();

                foreach (var item in wishList)
                {
                    $safeprojectname$ getEvent = db.$safeprojectname$.Where(x => x.Id == item.EventId).FirstOrDefault();
                    eventList.Add(getEvent);
                }

            }

            return View(eventList);
        }

        public ActionResult GoingUserList(int Id)
        {
            List<User> userList = new List<User>();

            List<Wish> filteredWishList = db.Wish.Where(x => x.EventId == Id && x.IsGone == true).ToList();
            foreach (var item in filteredWishList)
            {
                User goingUser = new User();
                goingUser = item.User;
                userList.Add(goingUser);
            }

            return View(userList);
        }





        /*
        public ActionResult AddWishList(int Id)
        {
            int _userId = (int)Session["UserId"];

            Wish wishCheck = db.Wish.Where(x => x.UserId == _userId && x.EventId == Id).FirstOrDefault();
            if (wishCheck == null)
            {
                Wish wish = new Wish();

                wish.UserId = (int)Session["UserId"];
                wish.EventId = Id;
                wish.AddDate = DateTime.Now;
                wish.IsGone = false;
                db.Wish.Add(wish);
                db.SaveChanges();
            }

            return RedirectToAction("WishList");
        }
        */

        public ActionResult DeleteWishList(int Id)
        {
            Wish wish = db.Wish.Where(x => x.EventId == Id).FirstOrDefault();

            db.Wish.Remove(wish);
            db.SaveChanges();

            return RedirectToAction("WishList");
        }


        public ActionResult IsGoneUpdate(int Id)
        {
            int _userId = (int)Session["UserId"];
            Wish wishControl = db.Wish.Where(x => x.UserId == _userId && x.EventId == Id).FirstOrDefault();

            if (wishControl != null)
            {
                Nullable<bool> goneControl = wishControl.IsGone;

                if (goneControl != null)
                {

                    if (goneControl == true)
                        wishControl.IsGone = false;

                    else if (goneControl == false)
                        wishControl.IsGone = true;

                    db.SaveChanges();
                }

            }
            else
            {
                Wish wish = new Wish();

                wish.UserId = (int)Session["UserId"];
                wish.EventId = Id;
                wish.AddDate = DateTime.Now;
                wish.IsGone = true;
                db.Wish.Add(wish);
                db.SaveChanges();

                return RedirectToAction("WishList");
            }

            return RedirectToAction("WishList");
        }


    }
}