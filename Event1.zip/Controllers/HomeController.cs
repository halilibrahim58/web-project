﻿using $safeprojectname$.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace $safeprojectname$.Controllers
{
    
    public class HomeController : Controller
    {
        EventDBEntities db = new EventDBEntities();


        // GET: Home
        public ActionResult Index()
        {//test
            List<Category> categoryList = db.Category.ToList();
            return View(categoryList);
        }

        public ActionResult ContactUs()
        {
            return View();
        }


    }
}